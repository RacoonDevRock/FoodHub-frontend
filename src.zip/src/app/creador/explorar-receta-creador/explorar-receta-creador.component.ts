import { Component } from '@angular/core';

@Component({
  selector: 'app-explorar-receta-creador',
  standalone: true,
  imports: [],
  templateUrl: './explorar-receta-creador.component.html',
  styleUrl: './explorar-receta-creador.component.css'
})
export class ExplorarRecetaCreadorComponent {

}
