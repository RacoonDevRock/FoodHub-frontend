export interface InstruccionDTO {
  instruccion: string;
}
