export interface CreadorDTO {
  nombre: string;
  apellidoPaterno: string;
  apellidoMaterno: string;
  correoElectronico: string;
  contrasenia: string;
  codigoColegiatura: string;
}
