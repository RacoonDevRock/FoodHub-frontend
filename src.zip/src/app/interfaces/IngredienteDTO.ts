export interface IngredienteDTO {
  ingrediente: string;
}
