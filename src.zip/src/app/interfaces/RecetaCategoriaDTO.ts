export interface RecetaCategoriaDTO {
  id: number;
  titulo: string;
  descripcion: string;
  imagenReceta: string;
}
