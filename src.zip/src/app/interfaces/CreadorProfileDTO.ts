export interface CreadorProfileDTO {
  nombre: string;
  apellidoPaterno: string;
  apellidoMaterno: string;
  correoElectronico: string;
  codigoColegiatura: string;
  fotoPerfil: string;
}
