export interface AuthDTO {
  identificador: string;
  contrasenia: string;
}
