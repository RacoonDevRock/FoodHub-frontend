import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { CreadorDTO } from '../interfaces/CreadorDTO';
import { Observable } from 'rxjs';
import { AuthDTO } from '../interfaces/AuthDTO';
import { CookieService } from 'ngx-cookie-service';
import {SharedService} from "./shared.service"; // Asegúrate de tener ngx-cookie-service instalado

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  public baseUrl: string = `${environment.apiUrl}/auth`;

  constructor(private http: HttpClient, private cookieService: CookieService, private sharedService: SharedService) {}

  registrarCreador(creadorDTO: CreadorDTO): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/registrar`, creadorDTO);
  }

  confirmation(token: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/confirmar?token=${token}`);
  }

  iniciarSesionCreador(authDTO: AuthDTO): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/login`, authDTO, {
      withCredentials: true,
    });
  }

  // Verifica si el usuario está autenticado
  isAuthenticated(): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/verify-auth`, {
      withCredentials: true, // Asegura que las cookies se envían y reciben
    });
  }
}
