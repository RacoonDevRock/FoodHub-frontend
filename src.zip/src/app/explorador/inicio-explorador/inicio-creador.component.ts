import { Component } from '@angular/core';
import {RouterLink} from "@angular/router";

@Component({
  selector: 'app-inicio-categorias-explorador',
  standalone: true,
  imports: [
    RouterLink
  ],
  templateUrl: './inicio-creador.component.html',
  styleUrl: './inicio-creador.component.css'
})
export class InicioCreadorComponent {

}
